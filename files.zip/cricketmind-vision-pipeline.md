# Vision Pipeline: Continuous Observation System

## Philosophy

The system doesn't "read a scoreboard every 3 seconds." It continuously
watches the broadcast at 2fps, classifies what type of content is on
screen, and routes each frame to the appropriate extractor. Different
frame types yield different information. The system watches the match
the way a commentator does — always observing, extracting different
things depending on what's being shown.

## Scene Types

| Scene | Visual Signature | Detection Method |
|-------|-----------------|------------------|
| `live_delivery` | Wide-angle bowling end, green field dominant, players small | Color histogram (>60% green) + aspect check |
| `live_aftermath` | Same wide angle but players clustered/moving | Follows live_delivery, persists 3-5s |
| `replay_slow_motion` | Zoomed in, possibly "REPLAY" text, different color grade | Frame-diff low (slow motion), zoom level high, OCR for "REPLAY" text |
| `player_closeup` | Face/upper body fills >30% of frame, skin tone dominant center | Face detection (MediaPipe or simple cascade) |
| `graphic_overlay` | Scoreboard, pitch map, wagon wheel, stats cards | High-contrast geometric shapes, text-heavy regions outside scoreboard area |
| `field_setting_view` | Overhead/wide with field markings, sometimes annotated dots | Very wide angle, pitch centered, often briefly shown |
| `crowd_shot` | Dense packed people, stands visible, colorful | High color variance, no large green area, many small objects |
| `analysis_segment` | Studio, split screen, presenters | Low green, faces in structured positions |
| `ad_break` | Logos, product shots, non-cricket content | No scoreboard visible, sudden scene change |

## Scene Classifier

```python
# Can be rule-based (fast, no RAM) or a tiny CNN (~100MB)
# Rule-based approach using frame properties:

class SceneClassifier:
    def classify(self, frame) -> str:
        hsv = cv2.cvtColor(frame, cv2.COLOR_BGR2HSV)
        green_ratio = count_green_pixels(hsv) / total_pixels

        # Check for scoreboard presence (consistent position)
        has_scoreboard = self.scoreboard_detector.check(frame)

        # Check for face in center
        has_face = self.face_detector.check_center(frame)

        # Check for slow motion (compare with prev frame)
        motion = frame_diff_magnitude(frame, self.prev_frame)

        # Check for replay text
        has_replay_text = self.ocr_quick.find_text(frame, ["REPLAY", "replay"])

        if has_replay_text or (has_face and motion < 0.01):
            return "replay_slow_motion"
        if has_face and not has_scoreboard:
            return "player_closeup" if face_size > 0.2 else "crowd_shot"
        if green_ratio > 0.5 and has_scoreboard:
            return "live_delivery"
        if green_ratio > 0.5 and not has_scoreboard:
            return "field_setting_view"  # or transition
        if has_scoreboard and green_ratio < 0.3:
            return "graphic_overlay"
        if not has_scoreboard and green_ratio < 0.2:
            return "ad_break"
        return "live_aftermath"  # default during play
```

Doesn't need to be perfect. 80% accuracy is fine — misclassification
means we extract less from that frame, not that we extract wrong data.

## Extractors by Scene Type

### live_delivery → Field Detector + Shot Capture

**When:** wide-angle bowling-end camera showing the delivery

**Field Detection (YOLO v8 nano)**
- Detect player positions as bounding boxes on the frame
- Map to cricket field zones (slip, gully, point, cover, mid-off,
  mid-on, midwicket, square leg, fine leg, deep positions)
- Output: `{fielders_off: 5, fielders_leg: 4, slips: 2, gully: 1,
  attacking: true, description: "2 slips, gully, point up, cover sweeper"}`
- YOLO v8 nano: ~50ms inference, ~200MB RAM, trained on COCO (persons class)
- Map person detections to field positions using pitch location as reference

**Shot Frame Capture**
- Capture 3-5 consecutive frames during the delivery (0.5s burst)
- These frames are queued for shot classification after the ball
- Don't process immediately — the delivery is still in progress

**Ball Direction (simple frame analysis)**
- After the shot, look at where motion is concentrated in the frame
- High motion toward off-side boundary → off-side shot
- High motion toward leg-side → leg-side shot
- Ball going aerial (motion in upper part of frame) → lofted
- Motion concentrated near batter (no travel) → dot ball or defense
- This is optical flow analysis, runs in <100ms with OpenCV

```python
def detect_ball_direction(prev_frames, curr_frame):
    flow = cv2.calcOpticalFlowFarneback(prev_gray, curr_gray, ...)
    # Divide frame into regions, find where flow magnitude is highest
    # Map to cricket field zones
    regions = {
        "off_side": flow[:, width//2:],    # right half for right-hander
        "leg_side": flow[:, :width//2],
        "aerial": flow[:height//3, :],      # top third = lofted
        "ground": flow[height//3:, :]
    }
    dominant = max(regions, key=lambda r: np.mean(np.abs(regions[r])))
    return dominant
```

### graphic_overlay → Scoreboard OCR + Graphics Reader

**When:** broadcast showing stats, pitch map, wagon wheel, or similar

**Scoreboard OCR (PaddleOCR)**
- Crop scoreboard region (fixed position, set during calibration)
- Extract: score, overs, batters, bowler, ball speed, run rate
- Compare with previous extraction → detect new ball event
- Sub-second, highly reliable on broadcast text

**Graphics Classification + Extraction (Vision model — Moondream)**
- If a non-scoreboard graphic is detected (pitch map, wagon wheel, etc.)
- Send cropped graphic region to Moondream with targeted prompt:

```
"Cricket broadcast graphic. Classify and extract:
PITCH_MAP: {line: outside_off|off|middle|leg|down_leg, length: yorker|full|good|short_of_length|short}
WAGON_WHEEL: {direction: cover|point|third_man|fine_leg|square_leg|midwicket|mid_on|mid_off|straight, ground: true|false}
BALL_SPEED: {kph: number}
STATS_CARD: {type: partnership|phase|matchup, summary: text}
OTHER: {description: text}
JSON only."
```

### player_closeup → Emotion + Body Language

**When:** camera zooms to a player's face between deliveries

**Emotion Classification (Moondream)**
```
"Cricket player close-up. Describe in JSON:
{player_likely: batter|bowler|captain|fielder,
 emotion: calm|focused|frustrated|angry|smiling|anxious|exhausted|intense,
 action: none|talking|wiping_sweat|adjusting_gear|looking_at_field|deep_breath|head_shake,
 energy: low|medium|high}"
```

This feeds directly into Tier 3 narrative commentary. The system
accumulates emotion observations over the innings and detects shifts:
"3 overs ago, the emotion reads were calm/focused. The last 2 close-ups
show frustrated/intense. Something has shifted."

### replay_slow_motion → Shot Detail Analysis

**When:** broadcast showing slow-motion replay (boundaries, wickets, close calls)

**Shot Mechanics (Moondream, async — not time-critical)**
```
"Slow-motion cricket replay. Analyze the batter's shot:
{shot_type: drive|cut|pull|hook|sweep|reverse_sweep|flick|scoop|loft|defense|leave|edge|miss,
 foot: front_foot|back_foot|crease|charged_down,
 bat_face: full|open|closed|cross_bat,
 contact: middle|edge|top_edge|bottom_edge|miss|pad,
 elevation: along_ground|low_aerial|high_aerial,
 power: gentle|timed|powerful|slog,
 ball_movement: straight|swing_in|swing_out|seam_in|seam_out|spin_in|spin_out|none_visible}
JSON only."
```

This enriches the ball event retroactively. The Tier 2 commentary
can be updated or a new "enrichment" message broadcast to the frontend.

### crowd_shot → Atmosphere Reading

**When:** camera showing the crowd

**Energy Classification (heuristic, no LLM needed)**
```python
def classify_crowd(frame):
    # Standing crowd = high energy (more vertical edges, motion)
    # Seated crowd = lower energy
    # Flags/banners = national pride moment
    # Many phones out = important moment
    motion = frame_diff_magnitude(frame, prev_frame)
    brightness = np.mean(frame)
    return {
        "energy": "high" if motion > threshold else "low",
        "atmosphere": "electric" if brightness > 180 else "tense"
    }
```

Or for important moments, use Moondream:
```
"Cricket crowd shot. Classify:
{energy: silent|murmuring|loud|roaring|stunned,
 mood: tense|excited|celebrating|disappointed|anxious}
JSON only."
```

### live_aftermath → Celebration/Reaction Detection

**When:** immediately after a delivery, players reacting

**Reaction Classification (YOLO + heuristic)**
- If multiple players running toward one spot → wicket celebration
- If batter raising bat → milestone
- Classify intensity:
  - Whole team converging = huge wicket
  - Single bowler fist pump = good ball
  - Keeper patting bowler = routine
  - Batter walking off = dismissed

Can also use Moondream for nuanced reads when a significant event is detected.

### field_setting_view → Tactical Layout

**When:** overhead or wide shot specifically showing field positions

**Field Extraction (YOLO + Moondream backup)**
- YOLO detects all player positions precisely
- If broadcast has annotated dots/circles on the graphic, OCR those
- Store as the authoritative field setting until next update
- This overrides the live_delivery YOLO reads (which are less precise
  due to camera angle)

### ad_break / analysis_segment → Background Processing

**When:** non-match content

Use this downtime for:
- Generate over summary for the last completed over
- Update narrative threads
- Generate prediction prompts
- Pre-compute engagement content
- Cleanup old audio files

## Main Observation Loop

```python
async def observation_loop():
    scene_clf = SceneClassifier()
    field_detector = YOLOFieldDetector()     # ~200MB
    scoreboard_ocr = PaddleOCR()             # ~500MB
    shot_frame_buffer = []
    prev_frame = None
    prev_ocr = None

    while True:
        frame = capture_frame()
        scene = scene_clf.classify(frame)

        if scene == "live_delivery":
            # Detect field positions (fast, every delivery)
            field = field_detector.detect(frame)
            game_state.update_field(field)
            # Capture frames for shot analysis
            shot_frame_buffer.append(frame)
            # Detect ball direction via optical flow
            if prev_frame is not None:
                direction = detect_ball_direction(prev_frame, frame)
                game_state.update_shot_direction(direction)

        elif scene == "graphic_overlay":
            # Run OCR on scoreboard crop
            ocr_data = scoreboard_ocr.extract(crop_scoreboard(frame))
            ball_event = detect_new_ball(ocr_data, prev_ocr)
            if ball_event:
                # Enrich with accumulated observations
                ball_event.field = game_state.last_field
                ball_event.shot_direction = game_state.last_shot_direction
                # Classify shot from buffered frames (async)
                if shot_frame_buffer:
                    asyncio.create_task(
                        classify_shot(shot_frame_buffer.copy(), ball_event))
                    shot_frame_buffer.clear()
                # Trigger commentary pipeline
                await process_ball_event(ball_event)
            # Also check for non-scoreboard graphics (pitch map, wagon wheel)
            graphic = detect_graphic_type(frame)
            if graphic:
                asyncio.create_task(extract_graphic_data(frame, graphic))
            prev_ocr = ocr_data

        elif scene == "player_closeup":
            # Async emotion analysis (not blocking)
            asyncio.create_task(analyze_player_emotion(frame))

        elif scene == "replay_slow_motion":
            # Queue for detailed shot analysis
            replay_queue.put(frame)

        elif scene == "crowd_shot":
            energy = classify_crowd_energy(frame)
            game_state.update_atmosphere(energy)

        elif scene in ("ad_break", "analysis_segment"):
            await do_background_tasks()

        prev_frame = frame
        await asyncio.sleep(0.5)  # 2 fps
```

## Memory Budget

| Component | RAM | Speed |
|-----------|-----|-------|
| Scene classifier (rule-based) | ~50 MB | <50ms |
| PaddleOCR | ~500 MB | <500ms |
| YOLO v8 nano (field detection) | ~200 MB | ~50ms |
| OpenCV optical flow | ~50 MB | <100ms |
| Moondream 1.7B (emotion, replay, graphics) | ~2 GB | ~2-3s |
| **Vision total** | **~2.8 GB** | |
| Mistral 7B (commentary) | ~5 GB | ~1-2s |
| Chatterbox Turbo (TTS) | ~3 GB | ~1-3s |
| OS + browser + stream | ~6 GB | |
| Backend + state | ~1 GB | |
| **System total** | **~17.8 GB** | |
| **Headroom on 32GB** | **~14 GB** | |

## Enriched Ball Event

After all extractors contribute:

```json
{
  "ball_number": "16.3",
  "runs": 4, "result": "four",
  "batter": "Suryakumar Yadav", "batter_runs": 45, "batter_balls": 28,
  "bowler": "Boult", "bowler_figures": "3-0-24-1",
  "delivery": {
    "speed_kph": 137.4,
    "line": "outside_off",
    "length": "good",
    "type": "seam",
    "movement": "seam_away"
  },
  "shot": {
    "type": "cut",
    "direction": "point",
    "foot": "back_foot",
    "elevation": "along_ground",
    "power": "timed",
    "contact": "middle"
  },
  "field": {
    "off_side": 5, "leg_side": 4,
    "slips": 1, "gully": 1,
    "description": "1 slip, gully, point up, deep cover, deep point"
  },
  "atmosphere": {
    "crowd_energy": "roaring",
    "batter_emotion": "confident",
    "bowler_emotion": "frustrated"
  },
  "source_confidence": {
    "score": "ocr_confirmed",
    "delivery": "pitch_map_graphic",
    "shot_type": "replay_analysis",
    "shot_direction": "optical_flow",
    "field": "yolo_live",
    "emotions": "closeup_analysis"
  }
}
```

## Graceful Degradation

Not every ball gets full enrichment. The system tracks what data
it actually captured vs inferred:

| Data Point | Best Source | Fallback | Worst Case |
|------------|-----------|----------|------------|
| Score/overs | OCR (99%) | — | Pipeline stops |
| Ball speed | OCR from graphic (80%) | Infer from bowler type | "pace" or "spin" |
| Line/length | Pitch map graphic (50%) | Infer from shot+direction | Omit from commentary |
| Shot type | Replay analysis (30%) | Optical flow + inference | Generic "found the boundary" |
| Shot direction | Wagon wheel (50%) | Optical flow (80%) | Omit specific direction |
| Field setting | YOLO on live (90%) | Last known setting | Omit field references |
| Batter emotion | Close-up analysis (40%) | Infer from situation | Omit body language |
| Crowd energy | Crowd shot analysis (30%) | Infer from match state | Generic atmosphere |

Commentary engine uses whatever is available. More data = richer
commentary. Less data = simpler but still accurate commentary.
System never fabricates data it doesn't have.

## Install Requirements

```bash
pip install paddlepaddle paddleocr  # OCR
pip install ultralytics             # YOLO v8
pip install opencv-python-headless  # OpenCV for optical flow, frame diff
pip install mediapipe               # Face detection (optional)
# Moondream via Ollama:
ollama pull moondream
```
