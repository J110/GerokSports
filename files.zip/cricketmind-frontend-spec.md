# Frontend Spec

## Tech Stack

- React (Vite), Tailwind utility classes only
- recharts for charts, lucide-react for icons
- Google Fonts: "DM Sans" (body), "JetBrains Mono" (numbers/data)
- No localStorage (not available) — use React state only

## Theme

```css
--bg-primary: #0a0f1a;
--bg-card: #111827;
--bg-card-hover: #1a2332;
--accent-batting: #22d3ee;   /* cyan — positive/batting */
--accent-bowling: #f43f5e;   /* rose — pressure/bowling */
--accent-gold: #fbbf24;      /* milestones, highlights */
--text-primary: #f1f5f9;
--text-secondary: #94a3b8;
--text-muted: #475569;
--border-subtle: #1e293b;
```

## Layout

```
Desktop (min-width: 1024px):
┌──────────────────────────────────────────┐
│          ScoreHeader (sticky)            │
├───────────────────┬──────────────────────┤
│ MatchAnimation    │ CommentaryFeed       │
│ (40% width)       │ (60% width)          │
│                   │                      │
├───────────────────┤ StoryStrip           │
│ StatsOverlay      ├──────────────────────┤
│ (collapsible)     │ EngagementPanel      │
│                   │ (tabbed)             │
└───────────────────┴──────────────────────┘
AudioPlayer: floating controls top-right

Mobile (<1024px):
ScoreHeader → MatchAnimation (shorter) → Tab bar:
[Commentary] [Stats] [Engage]
Each tab shows respective content full-width.
AudioPlayer: fixed bottom controls
```

## Components

### ScoreHeader
- Sticky top, bg-card, border-bottom subtle
- Row: team1 name | score/wickets (text-3xl, JetBrains Mono) | overs
- Row: batter1 stats | batter2 stats | bowler stats
- Phase badge: "POWERPLAY" / "MIDDLE" / "DEATH" — colored pill
- RR and RRR displayed, RRR in rose if > 10
- Green/yellow/red dot for WebSocket connection status
- Score number pulses (scale 1→1.05→1) on change via CSS transition

### CommentaryFeed
- Scrollable container, max-height calc(100vh - header)
- Items grouped by ball with left border-left (2px, border-subtle)
- **Tier 1**: `[16.3]` over badge (bg-card, rounded, small, mono font) + text + result pill
  - Result pill colors: "." → text-muted, "1/2/3" → text-secondary, "4" → accent-batting, "6" → accent-gold, "W" → accent-bowling
- **Tier 2**: margin-left 2rem, text-secondary, italic, `Lightbulb` icon (lucide, 14px)
- **Tier 3**: bg-card-hover, border-left 3px accent-gold, padding 12px, `BookOpen` icon
  - Show voice label: "📖 Narrator" in text-muted small text
- **Wicket card**: bg with rose/10 tint, border-left 3px accent-bowling, `AlertTriangle` icon
  - Animate in: translateY(8px)→0, opacity 0→1, 300ms ease-out
- **Milestone card**: border-left 3px accent-gold, `Trophy` icon
- **Featured comment**: `MessageSquare` icon, username bold, star badge, AI annotation in text-secondary below
- New items: animate slide-up 200ms
- Auto-scroll to bottom. If user scrolls up >100px, show "Jump to live ↓" button (fixed, bottom of feed, accent-batting bg)

### StoryStrip
- Horizontal scroll, flex row, gap-2, below CommentaryFeed
- Each pill: bg-card, rounded-full, px-3 py-1, small text
- Batting events: border accent-batting, Bowling: border accent-bowling
- Format: "[icon] Short label" e.g. "🏏 Allen 50 (28b)" or "🎯 3 wkts in 8 balls"
- Click → scroll CommentaryFeed to that ball group
- Auto-scroll right to latest pill

### AudioPlayer
- Floating top-right (desktop) or fixed bottom bar (mobile)
- Volume slider (range input, styled) + mute toggle button (`Volume2`/`VolumeX` icons)
- Voice indicator pill: bg-card, shows "🎙 Main" or "📖 Narrator" with fade transition
- Pulsing dot animation next to icon when audio playing
- When muted: show truncated text of current audio content in text-muted, max 40 chars
- Queue badge: if >1 pending, show count "3 🔊" in small text
- Implementation:
  ```js
  // Queue management
  const [queue, setQueue] = useState([])
  const audioRef = useRef(new Audio())
  // On new audio event: push to queue
  // On audio end: wait silence_before of next, then play
  // If queue.length > 3: filter out non-critical (keep wicket/narrative situations)
  ```

### StatsOverlay

**Above StatsOverlay, add MatchAnimation:**

### MatchAnimation
- SVG top-down cricket ground (dark green #1a3a2a oval, lighter outfield, tan pitch #c4a867)
- **Fielder dots**: when ball_event.field data available, show small dots
  representing fielder positions. Off-side dots cyan-tinted, leg-side neutral.
  Update each ball. This is a visual no text platform provides.
- Per-ball animations using enriched shot data:
  - Use shot.direction for accurate ball path (not random)
  - If shot.elevation is "high_aerial", arc the trajectory line
  - Dot: gray ripple at pitch. Single: white line to field zone.
    Four: line to boundary + cyan flash. Six: gold burst + particles.
    Wicket: red stumps flash + shake.
- Delivery info flash: if delivery.speed_kph available, show "137.4 kph"
  near bowler's end for 2s. If delivery.line/length available, show
  small pitch map dot on the pitch rectangle.
- This-over dots row at bottom, colored by result, resets per over.
- 2-3 second animations, CSS transitions on SVG elements.
- Stack of collapsible panels, each with header (click to toggle) + content
- Header: text-sm, text-secondary, chevron icon rotates on expand
- Panel 1 expanded by default, rest collapsed

**Win Probability** (2nd innings) / **Projected Score** (1st innings):
- recharts AreaChart, 200px height
- Data point per ball: {over: "16.3", value: 58}
- Fill: cyan above 50%, rose below (use two Area components with clip)
- Current value large above chart: "58%" in JetBrains Mono
- On key events: flash "+8%" (green) or "-12%" (rose) for 2 seconds

**Momentum Tide**:
- Single horizontal div, 100% width, 24px height, rounded
- Background: linear-gradient based on momentum_index
  - index=-1.0 → full rose, 0 → split, 1.0 → full cyan
- Above: row of 30 small circles (8px) for last 30 balls
  - dot→text-muted, single→text-secondary, four→accent-batting, six→accent-gold, wicket→accent-bowling

**Run Rate** (recharts LineChart, 150px height):
- Two lines: current RR (solid, cyan), required RR (dashed, rose)
- X axis: overs. Y axis: auto-scaled.

**Bowling Resources**:
- Per bowler: horizontal bar (width = overs_bowled/4 * 100%)
- Colors: economy <7 green-500, 7-10 amber-500, >10 rose-500
- Current bowler: ring/glow highlight
- Label: "Bumrah 3.3-0-28-1 (0.3 left)" in mono font, small

**Wagon Wheel** (SVG, 200x200):
- Circle (stroke text-muted, fill transparent) + center pitch rect
- Per scoring shot: line from center to boundary position
- Dot at endpoint, colored by result
- Angle from shot direction in ball_event data (estimate if not available)

### EngagementPanel
- Tabbed: ["Predict", "Chat", "Pulse"] — tab bar at top, bg-card tabs
- Active tab: border-bottom accent-batting

**Predict tab**:
- Quick-predict row: 6 buttons [•] [1] [2] [4] [6] [W]
  - Each 44x44px min, bg-card, rounded, mono font
  - After ball result: correct → flash green bg 500ms, wrong → flash red bg 500ms
  - Disabled for 3s after ball while waiting for next delivery
- Accuracy tracker: "You: 34% (12/35) | AI: 41% (14/35)" — text-sm, text-secondary
- If streak ≥ 3: "🔥 3 in a row!"
- Active prediction (if any): card with question, option buttons (single-select, highlight on pick), countdown bar (width shrinks), resolve animation (correct option glows green)
- Leaderboard: top 5 rows, rank + username + score. Current user highlighted with accent-batting bg

**Chat tab** (LiveChat):
- If no username set: show input + "Set name" button first
- Messages: reverse-chronological scroll (newest at bottom)
  - User's own: right-aligned, bg-card-hover, rounded-lg
  - Others: left-aligned, bg-card, rounded-lg
  - AI responses: left-aligned, border-left accent-gold, "🤖 CricketMind" label in text-muted
  - Featured: star icon ⭐ badge on message
- Input bar at bottom: text input + send button (accent-batting bg)
- After send: disable input 10 seconds, show countdown in placeholder text

**Pulse tab** (EmotionalPulse):
- 6 emoji buttons in row: 🔥 😰 😤 🎉 😱 💀
  - Each 48x48px, bg-card, rounded-lg
  - Selected: ring accent-gold, subtle scale(1.1)
  - Can change every 30s (cooldown timer on buttons)
- Distribution bar: horizontal stacked bar, colored segments per emoji
  - Width proportional to percentage
- Dominant display: large emoji + label "Crowd: 🔥 HYPED (67%)" centered
- Sparkline (recharts): 100px tall, last 5 overs of dominant emotion index

## Loading & Error States

- Before first ball_event: show "Waiting for match data..." centered, MatchAnimation in idle state (just the ground, no ball)
- WebSocket disconnected: yellow dot in header, "Reconnecting..." toast
- All panels show last known data even during reconnect
- If a component receives bad data, skip rendering that update silently

## Animations

- Score change: `transition: transform 150ms` scale pulse
- New commentary item: `@keyframes slideUp { from { opacity:0; transform:translateY(8px) } }`
- Voice switch: `transition: opacity 300ms` on voice indicator
- Tab switch: no animation, instant swap
- Panel expand/collapse: `transition: max-height 200ms ease-out`
