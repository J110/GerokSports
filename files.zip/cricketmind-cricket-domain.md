# Cricket T20 Domain Reference

## Match Structure

### T20I
- 2 innings, 20 overs each, 6 balls per over
- Total balls per innings: 120 (unless all out)
- Over notation: "16.3" = 16th over, 3rd ball
- Team batting second has target = first innings score + 1

### ODI
- 2 innings, 50 overs each, 6 balls per over
- Total balls per innings: 300 (unless all out)
- Same notation and target rules as T20I
- Two new balls (one from each end)

### Test
- 2 innings PER TEAM (up to 4 innings total)
- No over limit — innings ends when all out or captain declares
- Played over 5 days, 3 sessions per day (~90 overs/day)
- Win: bowl out opponent twice and score more runs
- Draw: time runs out without a result
- Follow-on: if team bats second and trails by 200+ runs,
  batting team may be asked to bat again immediately

## Phases

### T20I
| Phase | Overs | Character |
|-------|-------|-----------|
| Powerplay | 1-6 | Fielding restrictions, aggressive, ~8-10 RR par |
| Middle | 7-15 | Consolidation vs acceleration, ~7-9 RR par |
| Death | 16-20 | All-out attack, yorkers vs sixes, ~10-14 RR par |

### ODI
| Phase | Overs | Character |
|-------|-------|-----------|
| Powerplay 1 | 1-10 | Fielding restrictions, set the platform, ~5-6 RR par |
| Middle | 11-40 | Build partnerships, rotate strike, accelerate gradually, ~5-6 RR par |
| Death | 41-50 | Acceleration, big hitting, ~8-10 RR par |

### Test
| Phase | Session | Character |
|-------|---------|-----------|
| Morning | First 2 hours | Ball does most, bowler-friendly, patience crucial |
| Afternoon | Middle session | Batting easier, partnerships built |
| Evening | Final session | Tiring bowlers, old ball or reverse swing, light can play a role |
| Day 1-2 | Fresh pitch | Pace-friendly, bounce and carry |
| Day 3-4 | Deteriorating | Spin comes in, variable bounce, cracks form |
| Day 5 | Worn pitch | Spin dominant, survival batting, dramatic collapses |

## Ball Results

| Result | Runs | Notes |
|--------|------|-------|
| dot | 0 | Builds pressure, good for bowling |
| single | 1 | Rotates strike |
| two | 2 | Good running |
| three | 3 | Rare |
| four | 4 | Boundary along ground |
| six | 6 | Over the boundary (most exciting) |
| wicket | 0 | Batter dismissed (10 wickets = all out) |
| wide | 1 extra | Plus re-bowl (doesn't count as ball) |
| no_ball | 1 extra | Plus free hit next ball |

## Key Metrics

- **Run Rate (RR)**: runs / overs. T20 par ~8.0-8.5, ODI par ~5.5-6.0
- **Required Rate (RRR)**: runs needed / overs remaining. T20: >12 = very hard. ODI: >8 = very hard
- **Economy**: bowler runs per over. T20: <7 good, >10 bad. ODI: <5 good, >7 bad. Test: <3 good
- **Strike Rate**: batter runs per 100 balls. T20: >150 aggressive. ODI: >100 good. Test: >60 good
- **Dot Ball %**: balls scoring 0. >40% = bowling dominant (T20), >50% normal in Test
- **Average (Test/ODI)**: runs per dismissal. >40 = elite batter

## Milestones

- Batter: 50 (half-century), 100 (century — rare in T20)
- Partnership: 50, 100
- Bowler: 3 wickets, 5 wickets (extremely rare)
- Team: 100 runs, 150 runs, 200 runs

## Shot Types (for animation direction)

| Shot | Direction (degrees, 0=straight back) |
|------|--------------------------------------|
| straight drive | 0° |
| cover drive | 315° (off side) |
| square cut | 270° (point) |
| pull/hook | 225° (midwicket) |
| flick | 200° (fine leg) |
| sweep | 240° (square leg) |
| loft over bowler | 0° (aerial) |
| scoop/ramp | 160° (fine leg, behind) |

## Bowling Lines (for pitch map x-coordinate)

- Outside off: 0.2 (right of center for right-hander)
- Off stump: 0.35
- Middle: 0.5
- Leg stump: 0.65
- Down leg: 0.8

## Bowling Lengths (for pitch map y-coordinate)

- Yorker: 0.9 (at batsman's feet)
- Full: 0.75
- Good length: 0.55
- Short of length: 0.35
- Short/bouncer: 0.15

## Emotional Intensity by Situation

| Situation | Intensity | Commentary Style |
|-----------|-----------|------------------|
| Dot ball, middle overs | Low | Calm, analytical |
| Single, normal play | Low | Brief, factual |
| Boundary, normal play | Medium | Descriptive, appreciative |
| Six, any phase | High | Excited, vivid |
| Six, death overs in chase | Very High | Electric, dramatic |
| Wicket, any | High | Dramatic pause, then analysis |
| Wicket that changes game | Very High | Extended dramatic treatment |
| Milestone (50/100) | High | Celebratory, historical context |
| Last over, close match | Maximum | Tense, every ball matters |
| Match-winning shot | Maximum | Peak emotion, narrative climax |
| Rain delay / drinks break | Low | Reflective, analytical summary |

## Narrative Triggers

When to generate deeper commentary (Tier 3):
- Fall of wicket (always)
- Milestone reached (always)
- End of powerplay (always)
- Start of death overs (always)
- 3+ consecutive dot balls after boundaries (momentum shift)
- 2+ boundaries in an over (batting surge)
- Dropped catch or close DRS review (drama)
- New batter facing first ball (tension)
- Required rate crosses 12 (pressure point)
- Win probability shifts >15% in 2 overs (turning point)
