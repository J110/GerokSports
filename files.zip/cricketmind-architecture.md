# Architecture Reference

## Data Flow

```
capture.py → observation_loop (continuous, 2fps)
  ├─ scene_classifier  → routes frames to extractors
  ├─ scoreboard_ocr    → score, overs, batters, bowler, speed
  ├─ field_detector    → fielder positions via YOLO
  ├─ optical_flow      → ball/shot direction
  ├─ graphics_reader   → pitch map, wagon wheel (Moondream)
  ├─ emotion_reader    → player body language (Moondream)
  ├─ replay_analyzer   → shot mechanics, ball movement (Moondream)
  └─ crowd_reader      → atmosphere energy
         │
         ▼ enriched BallEvent
  game_state.py → commentary.py → audio.py
               → narrative.py
               → engagement.py / chat_handler.py

context_builder.py (pre-match, scrapes web for historical context)
All outputs → main.py (WebSocket) → React frontend
```

## Module Responsibilities

| Module | Input | Output | Deps |
|--------|-------|--------|------|
| capture.py | Screen | Frames at 2fps | mss |
| scene_classifier.py | Frame | Scene type string | OpenCV, optional MediaPipe |
| scoreboard_ocr.py | Scoreboard crop | Structured score data | PaddleOCR |
| field_detector.py | Wide-angle frame | Fielder positions | YOLO v8 nano |
| shot_analyzer.py | Frame sequence + replay | Shot type, direction, mechanics | OpenCV optical flow, Moondream |
| vision.py | All extractors | Enriched BallEvent + observations | Orchestrator |
| game_state.py | BallEvent + field + atmosphere | StateUpdate | None |
| commentary.py | GameState, Narrative, Context | CommentaryOutput | Ollama (mistral:7b) |
| narrative.py | StateUpdate + emotion observations | Active threads | None |
| audio.py | Text + voice + situation | AudioOutput | Chatterbox Turbo |
| engagement.py | GameState | Predictions, scores | None |
| chat_handler.py | User messages + GameState | AI responses | Ollama (mistral:7b) |
| context_builder.py | Team names + venue | Historical context JSON | httpx, bs4, Ollama |
| main.py | All modules | WebSocket broadcast | FastAPI |

## Two Main Loops

### Observation Loop (continuous, 2fps) — see docs/vision-pipeline.md

```python
async def observation_loop():
    while True:
        frame = capture_frame()
        scene = scene_classifier.classify(frame)
        if scene == "live_delivery":
            game_state.update_field(yolo.detect(frame))
            shot_buffer.append(frame)
            game_state.update_shot_direction(optical_flow(prev, frame))
        elif scene == "graphic_overlay":
            ocr = scoreboard_ocr.extract(crop(frame))
            ball = detect_new_ball(ocr, prev_ocr)
            if ball:
                ball.enrich(game_state)
                asyncio.create_task(classify_shot(shot_buffer, ball))
                await process_ball_event(ball)
            check_for_graphics(frame)
        elif scene == "player_closeup":
            asyncio.create_task(analyze_emotion(frame))
        elif scene == "replay_slow_motion":
            replay_queue.put(frame)
        elif scene == "crowd_shot":
            game_state.update_atmosphere(classify_crowd(frame))
        prev_frame = frame
        await asyncio.sleep(0.5)
```

### Commentary Pipeline (triggered per ball)

```python
async def process_ball_event(ball):
    su = game_state.update(ball)
    narrative.update(su)
    await broadcast("ball_event", ball)
    await broadcast("state_update", game_state.to_client_payload())
    engagement.resolve_quick_predict(ball)
    t1 = await commentary.generate_tier1(ball, game_state)
    await broadcast("commentary_t1", t1)
    if t1.should_voice:
        aud = await audio.generate(t1.text, t1.voice_profile, t1.voice_situation)
        await broadcast("audio", aud)
    await asyncio.sleep(1.0)
    t2 = await commentary.generate_tier2(game_state)
    if t2.text: await broadcast("commentary_t2", t2)
    if commentary.should_generate_tier3(game_state, narrative):
        await asyncio.sleep(1.5)
        t3 = await commentary.generate_tier3(game_state, narrative)
        if t3.text:
            await broadcast("commentary_t3", t3)
            aud = await audio.generate(t3.text, "narrator", t3.voice_situation)
            await broadcast("audio", aud)
```

### Background Tasks

- `replay_analyzer_loop`: Moondream on queued replay frames → enriches last ball
- `chat_response_loop`: AI responds to user chat with game context
- `audio_cleanup_loop`: deletes audio files >10 min old

## Memory Budget (32GB M1 Max)

| Component | RAM |
|-----------|-----|
| Vision stack (scene clf + OCR + YOLO + OpenCV) | ~800 MB |
| Moondream 1.7B (emotion, replay, graphics) | ~2 GB |
| Mistral 7B (commentary + chat) | ~5 GB |
| Chatterbox Turbo (TTS) | ~3 GB |
| OS + browser + stream | ~6 GB |
| Backend + state | ~1 GB |
| **Total ~17.8 GB / Headroom ~14.2 GB** | |

## FastAPI Server

State machine (see docs/match-setup.md):
```
IDLE → SETUP → BUILDING_CONTEXT → CALIBRATING → LIVE → MATCH_COMPLETE
  └──────────────── (reset) ◄──────────────────────────────────────────┘
```

Models load once on startup. Match state resets without reloading models.

```python
@app.on_event("startup")
async def startup():
    await audio_engine.initialize()  # Chatterbox loads once
    # Ollama models (Moondream, Mistral) loaded on first call, stay resident
    # observation_loop starts on POST /setup/go-live, not on startup
```

Endpoints: WS /ws, GET /state, /commentary, /predictions/leaderboard,
/health, /context/status, POST /set-match

## Directory Layout

```
cricketmind/
├── backend/
│   ├── main.py, capture.py, vision.py
│   ├── scene_classifier.py, scoreboard_ocr.py
│   ├── field_detector.py, shot_analyzer.py
│   ├── game_state.py, commentary.py, narrative.py, audio.py
│   ├── engagement.py, chat_handler.py, context_builder.py
│   ├── types.py, config.py
│   ├── prompts/, voices/, static/audio/
├── frontend/src/
│   ├── App.jsx, hooks/, components/
└── docs/
```
