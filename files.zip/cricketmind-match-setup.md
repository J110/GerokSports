# Match Setup

## Flow

```
System starts → opens http://localhost:8000
  → Setup screen (no match loaded yet)
  → User enters match details
  → Context builder runs (~60-90s)
  → Calibration: user selects scoreboard region
  → System goes live, observation loop starts
  → Frontend switches from setup to match view
```

## Setup Interface

### Option A: REST endpoint (for CLI users)

```
POST /setup/match
{
  "team_a": "India",
  "team_b": "New Zealand",
  "format": "T20I",
  "event": "T20 World Cup 2026 Final",   // optional
  "venue": "Narendra Modi Stadium",       // optional
  "date": "2026-03-08",                   // optional, helps context builder find right match
  "is_live": false                        // true = upcoming/live, false = historical replay
}

Response:
{
  "status": "building_context",
  "match_id": "ind-vs-nz-t20wc-2026-final",
  "estimated_seconds": 90
}
```

### Option B: Web UI setup page (for demo)

The frontend shows a setup screen before any match is loaded.
Clean, simple form:

```
┌─────────────────────────────────────────┐
│           🏏 CricketMind                │
│                                         │
│  Team A:  [India          ▾]            │
│  Team B:  [New Zealand    ▾]            │
│  Format:  [T20I] [ODI] [Test]           │
│                                         │
│  Event:   [T20 World Cup 2026 Final   ] │
│  Venue:   [Narendra Modi Stadium      ] │
│  Date:    [2026-03-08                 ] │
│                                         │
│  ○ Live / Upcoming match                │
│  ● Historical replay (YouTube etc)      │
│                                         │
│  [Start Match →]                        │
└─────────────────────────────────────────┘
```

Team dropdowns populated with all ICC full member + associate teams.
Event, venue, date are optional free text — help context builder
find the right data but system works without them.

Format matters because it changes:
- Game state rules (overs per innings, powerplay structure)
- Commentary style and pacing
- Stats context (T20I records vs ODI records)

### Option C: Quick start with just team names

```
POST /setup/quick
{"teams": "India vs New Zealand"}

System parses team names, assumes T20I, builds context.
Useful for fast testing.
```

## What Happens After Setup

### 1. Context Builder Activates

Receives the match details and starts scraping:

**For live/upcoming matches:**
- Scrape current squad lists (ESPNcricinfo series page)
- Scrape tournament context if event specified
- Scrape head-to-head T20I/ODI/Test records
- Scrape venue stats
- Scrape recent form for both teams
- Generate commentary hooks and pre-match analysis

**For historical matches:**
- Same scraping, but context builder also looks for:
  - The specific match scorecard (if date + teams given)
  - This lets it pre-load the actual result, key performers,
    and milestone events — BUT it doesn't feed these to
    the commentary engine (that would be spoilers)
  - Instead, it uses the historical data to generate better
    hooks: "Allen went on to score X in this match" becomes
    available as a post-match hook, not used during live commentary
- Player stats are fetched as of that match date, not current
  (when possible — ESPNcricinfo archive pages have historical data)

**Shared across both modes:**
- Head-to-head rivalry history
- Venue records
- Tournament context (if event specified)
- Key matchup data
- LLM-generated commentary hooks

### 2. Calibration Screen

After context is built, frontend shows calibration view:

```
┌─────────────────────────────────────────┐
│  Context loaded: India vs New Zealand   │
│  T20 World Cup 2026 Final              │
│  Players: 11 + 11 loaded               │
│  Venue stats: ✓  H2H: ✓  Hooks: ✓     │
│                                         │
│  Now play the match video/stream and    │
│  click the corners of the scoreboard:   │
│                                         │
│  [Click to open screen overlay →]       │
│                                         │
│  Then press [Go Live] to start.         │
└─────────────────────────────────────────┘
```

User clicks "open screen overlay" → tkinter/pygame transparent
overlay appears → user clicks 4 corners of scoreboard region →
coordinates saved → user clicks "Go Live" → observation loop starts.

### 3. System Goes Live

Frontend transitions from setup view to the full match interface
(score header, commentary feed, stats, engagement, etc.)

All components start in "waiting for first ball" state.
Observation loop begins processing frames.

## State Machine

```
IDLE → SETUP → BUILDING_CONTEXT → CALIBRATING → LIVE → MATCH_COMPLETE
  │                                                        │
  └──────────────── (reset) ◄──────────────────────────────┘
```

Server tracks state and exposes it:

```
GET /setup/status
{
  "state": "LIVE",                    // IDLE|SETUP|BUILDING_CONTEXT|CALIBRATING|LIVE|MATCH_COMPLETE
  "match": {
    "team_a": "India",
    "team_b": "New Zealand",
    "format": "T20I",
    "event": "T20 World Cup 2026 Final",
    "is_live": false
  },
  "context_status": "ready",          // building|ready|partial|error
  "context_loaded": {
    "players": true,
    "venue": true,
    "h2h": true,
    "tournament": true,
    "hooks": true
  },
  "calibration": {
    "scoreboard_region": [x1, y1, x2, y2],  // null if not calibrated
    "ready": true
  },
  "observation": {
    "frames_processed": 1247,
    "balls_detected": 42,
    "scenes_detected": {"live_delivery": 340, "graphic_overlay": 280, ...}
  }
}
```

## Match Reset

To switch to a different match without restarting the server:

```
POST /setup/reset

Clears: game_state, commentary log, narrative threads,
  prediction scores, chat history, audio files, context
Keeps: models loaded (Moondream, Mistral, Chatterbox)
Returns to IDLE state
Frontend shows setup screen again
```

This is fast (~1 second) because models stay in memory.
User can switch from testing on YouTube replays to the live
match without restarting anything.

## Format-Specific Configuration

The format selection changes game_state behavior:

```python
FORMAT_CONFIG = {
    "T20I": {
        "overs_per_innings": 20,
        "max_bowler_overs": 4,
        "powerplay_overs": [1, 6],
        "middle_overs": [7, 15],
        "death_overs": [16, 20],
        "par_score_range": [160, 180],
        "high_score_threshold": 200,
    },
    "ODI": {
        "overs_per_innings": 50,
        "max_bowler_overs": 10,
        "powerplay_overs": [1, 10],
        "middle_overs": [11, 40],
        "death_overs": [41, 50],
        "par_score_range": [270, 300],
        "high_score_threshold": 350,
    },
    "TEST": {
        "overs_per_innings": None,  # unlimited
        "max_bowler_overs": None,
        "powerplay_overs": None,
        "sessions": ["morning", "afternoon", "evening"],
        "par_score_range": None,
    }
}
```

Commentary prompts also adapt:
- T20I: more excitement, boundary-focused, pressure metrics
- ODI: pacing narratives, partnership building, phase transitions
- Test: session narratives, pitch deterioration, patience/attrition

## Testing Workflow

Typical testing session:

```
1. Start server: uvicorn backend.main:app
2. Open localhost:8000 → setup screen
3. Enter: "India" vs "Australia", T20I, "2024 World Cup Group"
4. Wait ~60s for context to build
5. Open YouTube: "India vs Australia T20 World Cup 2024 Highlights"
6. Calibrate scoreboard region
7. Click "Go Live"
8. Watch system process the replay
9. When done: POST /setup/reset
10. Enter new match, repeat
```

Can cycle through multiple test matches in one session
without restarting any models or services.

## Frontend Setup Components

### SetupScreen.jsx

Shown when state is IDLE or SETUP:
- Match details form (teams, format, event, venue, date, live/historical toggle)
- Team dropdowns with search/autocomplete
- "Start Match" button → POST /setup/match

### ContextLoadingScreen.jsx

Shown when state is BUILDING_CONTEXT:
- Progress indicators for each data source
- "Players loaded ✓" "Venue stats loaded ✓" etc
- Estimated time remaining

### CalibrationScreen.jsx

Shown when state is CALIBRATING:
- Instructions for scoreboard region selection
- Button to open the screen overlay tool
- Display of selected region coordinates
- "Go Live" button → transitions to LIVE state

### App.jsx routing

```jsx
function App() {
  const { setupState } = useWebSocket();

  if (setupState === "IDLE" || setupState === "SETUP")
    return <SetupScreen />;
  if (setupState === "BUILDING_CONTEXT")
    return <ContextLoadingScreen />;
  if (setupState === "CALIBRATING")
    return <CalibrationScreen />;
  // LIVE or MATCH_COMPLETE
  return <MatchView />;  // the full commentary experience
}
```
