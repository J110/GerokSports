# Context Builder Module

## Purpose

Automatically builds rich historical context for the AI commentary
engine. Runs during the ~30 minute gap between toss and first ball.
Scrapes publicly available data and structures it for the commentary
LLM to reference throughout the match.

## When It Runs

```
Stream goes live (pre-match graphics visible)
  → Vision model extracts team names from broadcast
  → context_builder.build(team_a, team_b, venue) kicks off
  → Scrapes all sources in parallel
  → Structures into context.json
  → Commentary engine loads context.json into system prompts
  → Ready before first ball
```

If team names can't be extracted from broadcast, user manually enters
them via a simple CLI prompt or /set-teams REST endpoint.

## Architecture

```
File: backend/context_builder.py

class ContextBuilder:
    async def build(team_a: str, team_b: str, venue: str = None) -> dict
    
    Orchestrates parallel scraping of all data sources.
    Returns structured context dict, saved to cricket_data/context.json.
    
    Takes ~2-5 minutes to fully populate. Commentary engine can start
    with partial context and hot-reload as more data arrives.
```

## Data Sources (all public, no API keys needed)

### 1. ESPNcricinfo — Primary Source

Base: https://www.espncricinfo.com

**Series page** — current tournament stats
- URL pattern: /series/{series_slug}/match-schedule-fixtures-and-results
- Extract: all match results, team paths through tournament

**Head-to-head** — rivalry stats
- URL pattern: /records/headtohead/team-match-results/{team_a}-{team_b}/twenty20-internationals-3
- Extract: H2H record, recent results, notable matches

**Player profiles** — squad member stats
- URL pattern: /player/{player_slug}/matches
- Extract: recent form (last 10 T20I innings), career T20I stats

**Venue records**
- URL pattern: /cricket-grounds/{venue_slug}/records
- Extract: highest/lowest scores, avg first innings score, chase success rate

### 2. Wikipedia — Tournament and Historical Context

- Tournament page: current edition overview, records, milestones
- Team T20 WC history: past finals, semi-finals, best finishes
- Venue history: notable matches played there

### 3. ICC Website — Current Tournament Stats

- Stats tracker page: leading run-scorers, wicket-takers
- Team pages: squad lists, recent form

## Output Structure

```json
{
  "match": {
    "event": "T20 World Cup 2026 Final",
    "team_a": "India",
    "team_b": "New Zealand",
    "venue": "Narendra Modi Stadium, Ahmedabad",
    "date": "2026-03-08",
    "toss": null
  },

  "venue": {
    "name": "Narendra Modi Stadium",
    "city": "Ahmedabad",
    "capacity": 132000,
    "aka": "Motera",
    "t20_matches_hosted": 10,
    "avg_first_innings_score_t20": null,
    "bat_first_win_pct": null,
    "highest_t20_score": null,
    "lowest_t20_score": null,
    "notable_facts": [
      "Largest cricket stadium in the world",
      "Sunil Gavaskar reached 10,000 Test runs here",
      "Hosted 2023 ODI World Cup final"
    ],
    "recent_matches_here_this_tournament": []
  },

  "rivalry": {
    "t20i_head_to_head": {"total": 25, "team_a_wins": 14, "team_b_wins": 10, "tied": 1},
    "recent_icc_encounters": [
      {"event": "2025 Champions Trophy Final", "winner": "New Zealand", "summary": "..."},
      {"event": "2025 WTC Final", "winner": "New Zealand", "summary": "..."}
    ],
    "narrative": "NZ have won 3 of last 4 ICC finals/knockouts against India...",
    "last_t20i_meeting": {"date": "...", "result": "...", "venue": "..."}
  },

  "tournament": {
    "edition": "10th",
    "hosts": "India and Sri Lanka",
    "teams": 20,
    "matches": 55,
    "defending_champions": "India (won 2024 in West Indies)",
    "leading_run_scorers": [
      {"name": "Sahibzada Farhan", "team": "Pakistan", "runs": 383, "matches": 7, "note": "Broke Kohli's record"},
      {"name": "...", "team": "...", "runs": 0}
    ],
    "leading_wicket_takers": [
      {"name": "Shadley van Schalkwyk", "team": "USA", "wickets": 13, "matches": 4},
      {"name": "...", "team": "...", "wickets": 0}
    ],
    "records_broken": [
      "Most centuries in a single edition (6)",
      "Finn Allen: fastest century in WC history (33 balls)",
      "Sahibzada Farhan: first player with 2 centuries in one WC edition",
      "Harry Brook: first captain to score a WC century"
    ],
    "storylines": [
      "Italy qualified for first time",
      "Bangladesh withdrew; replaced by Scotland",
      "Romario Shepherd hat-trick on opening day"
    ]
  },

  "team_a": {
    "name": "India",
    "captain": "...",
    "coach": "...",
    "t20_wc_history": {
      "titles": ["2007", "2024"],
      "finals": ["2007", "2014", "2024", "2026"],
      "best_finish_this_cycle": "Defending champions"
    },
    "path_to_final": [
      {"match": "vs USA", "result": "Won by X runs", "key_performer": "..."},
      {"match": "vs Namibia", "result": "...", "key_performer": "..."}
    ],
    "form_this_tournament": {
      "played": 0, "won": 0, "lost": 0,
      "avg_score_batting_first": null,
      "avg_score_chasing": null,
      "powerplay_avg": null
    },
    "key_players": [
      {
        "name": "...",
        "role": "batter/bowler/allrounder",
        "tournament_stats": {"runs": 0, "balls": 0, "sr": 0, "wickets": 0, "economy": 0},
        "career_t20i": {"matches": 0, "runs": 0, "wickets": 0, "avg": 0},
        "recent_form": "last 5 innings scores or figures",
        "vs_opponent": "stats against the other team if available",
        "narrative_hooks": [
          "Any milestones approaching",
          "Any notable history at this venue",
          "Any story from this tournament worth referencing"
        ]
      }
    ],
    "strengths": [],
    "vulnerabilities": []
  },

  "team_b": {
    "...same structure as team_a..."
  },

  "key_matchups": [
    {
      "batter": "...",
      "bowler": "...",
      "data": "T20I: 15 balls, SR 180, dismissed once",
      "narrative": "..."
    }
  ],

  "pre_match_analysis": {
    "conditions": "evening match, dew likely in 2nd innings, Ahmedabad typically batting-friendly",
    "toss_factor": "teams batting second have won X of Y T20Is at this venue",
    "key_battle": "India's spin (Varun/Axar) vs NZ's aggressive openers (Allen/Seifert)",
    "x_factor_team_a": "...",
    "x_factor_team_b": "...",
    "prediction_factors": [
      "Dew: advantage to chasing team",
      "NZ momentum from semi-final demolition",
      "India's home crowd: 132,000 fans"
    ]
  },

  "commentary_hooks": [
    "If Allen passes 30: 'He did this in the semi too — reached 34 off 21 before shifting gears to score 66 off his next 12 balls'",
    "If Bumrah bowls in death: 'Best death-over economy in the tournament at X.XX'",
    "If NZ batting collapses: 'Their middle order was never tested in the semi — Allen and Seifert did it all'",
    "If India bats first above 180: 'Only one team has successfully chased 180+ at this venue in T20Is'",
    "If Ravindra bowls: 'Leading spinner in the tournament with 11 wickets, and he dismissed Allen's KKR teammate Markram in the semi'",
    "First wicket falls: 'In the semi, NZ never lost this early — SA couldn't separate Allen and Seifert until 117'",
    "If match goes to last over: reference 2024 final (India defended in last over vs SA)"
  ]
}
```

## Scraping Implementation

```python
class ContextBuilder:
    def __init__(self):
        self.context = {}
        self.status = "idle"  # idle | building | ready | error

    async def build(self, team_a: str, team_b: str, venue: str = None):
        self.status = "building"

        # Run all scrapers in parallel
        results = await asyncio.gather(
            self._scrape_tournament_stats(),
            self._scrape_head_to_head(team_a, team_b),
            self._scrape_team_info(team_a),
            self._scrape_team_info(team_b),
            self._scrape_venue_stats(venue),
            self._scrape_tournament_context(),
            return_exceptions=True
        )

        # Assemble context from results (skip any that errored)
        self._assemble(results)

        # Generate commentary hooks using LLM
        await self._generate_hooks()

        # Generate pre-match analysis using LLM
        await self._generate_analysis()

        # Save
        self._save("cricket_data/context.json")
        self.status = "ready"

    async def _scrape_tournament_stats(self):
        """Scrape leading run scorers, wicket takers, records from
        ESPNcricinfo series page and ICC stats tracker."""
        ...

    async def _scrape_head_to_head(self, team_a, team_b):
        """Scrape T20I H2H record, recent ICC encounters, last meeting.
        Sources: ESPNcricinfo H2H page, Wikipedia."""
        ...

    async def _scrape_team_info(self, team):
        """Scrape squad list, player profiles, tournament path,
        form stats. ESPNcricinfo team/player pages."""
        ...

    async def _scrape_venue_stats(self, venue):
        """Scrape venue T20 records: avg scores, bat-first win %,
        highest/lowest, recent matches.
        ESPNcricinfo venue records page."""
        ...

    async def _scrape_tournament_context(self):
        """Scrape broader tournament narrative: records broken,
        storylines, milestones. Wikipedia tournament page."""
        ...

    async def _generate_hooks(self):
        """Use Mistral to generate commentary hooks from raw data.
        Input: all scraped data.
        Output: list of if-then commentary triggers.

        Prompt:
        'Given this match context data, generate 15-20 specific
        commentary hooks. Each hook should be an if-then:
        IF [specific match situation], THEN [what to say].
        Make them specific to this match, these players, this venue.
        Include: player milestones approaching, historical parallels,
        tactical angles, emotional narrative threads.
        Return as JSON array of {trigger, commentary} objects.'
        """
        ...

    async def _generate_analysis(self):
        """Use Mistral to generate pre-match analysis from raw data.
        Prompt:
        'Given this match data, write:
        1. Three key battles that will decide the match
        2. Two tactical predictions for each team
        3. Conditions analysis (venue, weather, toss impact)
        4. One surprise prediction most people won't expect
        Keep each point to 1-2 sentences. Be specific, not generic.'
        """
        ...

    def get_context(self) -> dict:
        """Return current context. May be partial if still building."""
        return self.context

    def get_player_context(self, player_name: str) -> dict | None:
        """Quick lookup of a specific player's data for commentary."""
        ...

    def get_hooks_for_situation(self, situation: dict) -> list[str]:
        """Return relevant commentary hooks for current match state.
        Matches situation (score, batter, phase, etc.) against
        hook triggers. Returns applicable hooks sorted by relevance."""
        ...
```

## Integration with Commentary Engine

The commentary engine gets context injected into its system prompts:

```python
# In commentary.py, when generating any tier:

context = context_builder.get_context()
player_ctx = context_builder.get_player_context(batter_name)
hooks = context_builder.get_hooks_for_situation(game_state.to_dict())

# Append to the system prompt for Tier 2 and Tier 3:
context_addendum = f"""
MATCH CONTEXT (reference naturally, don't force):
- Rivalry: {context['rivalry']['narrative']}
- Venue: {context['venue']['notable_facts']}
- Tournament: {context['tournament']['records_broken']}

CURRENT PLAYER: {player_ctx}

RELEVANT HOOKS (use if the moment is right):
{hooks}
"""
```

Context is NOT injected into Tier 1 (ball description) — that needs
to stay fast and light. Only Tier 2 (analysis) and Tier 3 (narrative)
get the enriched context.

## Pipeline Integration

```python
# In main.py startup:

@app.on_event("startup")
async def startup():
    # ... other init ...
    # Context builder initializes but doesn't run yet
    context_builder = ContextBuilder()

# Two ways to trigger context building:

# 1. Auto-detect from broadcast (preferred)
# When vision model first extracts team names from pre-match graphics:
if extraction.get("batting_team") and not context_builder.status == "ready":
    team_a = extraction["batting_team"]
    team_b = extraction["bowling_team"]
    asyncio.create_task(context_builder.build(team_a, team_b, venue))

# 2. Manual trigger via REST endpoint
@app.post("/set-match")
async def set_match(team_a: str, team_b: str, venue: str = ""):
    asyncio.create_task(context_builder.build(team_a, team_b, venue))
    return {"status": "building"}

@app.get("/context/status")
async def context_status():
    return {"status": context_builder.status}
```

## Timing Budget

| Task | Estimated Time |
|------|---------------|
| Tournament stats scrape | ~10s |
| H2H scrape | ~5s |
| Team A info (squad + player stats) | ~30s (multiple player pages) |
| Team B info | ~30s |
| Venue stats | ~5s |
| Tournament narrative (Wikipedia) | ~10s |
| Generate hooks (LLM) | ~10s |
| Generate analysis (LLM) | ~10s |
| **Total (parallel)** | **~60-90 seconds** |

Plenty of time in the 30-minute pre-match window. Context builder
can also run in background and hot-update — commentary engine
checks for latest context on each generation.

## Fallback

If scraping fails for any source:
- Log warning, continue with partial context
- Commentary still works — it just won't have that specific data
- Hooks and analysis skip anything that failed to load
- Worst case: commentary runs without historical context, which is
  what Session 1-5 already handles

## Scraping Notes

- Use httpx with 10-second timeout per request
- Respect robots.txt and rate-limit to 1 request/second per domain
- Parse with BeautifulSoup, extract text content
- For structured data (stats tables), look for specific CSS classes
  or table structures on ESPNcricinfo
- Cache all results to disk — if the same match context is needed
  again (e.g., server restart), load from cache instead of re-scraping
- ESPNcricinfo pages are server-rendered HTML — no JS rendering needed
