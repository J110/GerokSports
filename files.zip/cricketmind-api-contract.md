# API Contract

## WebSocket: /ws

### Server → Client Messages

```jsonc
// Score changed, new ball bowled (enriched by vision pipeline)
{"type": "ball_event", "data": {
    "ball_number": "16.3",
    "runs": 4,
    "result": "four",       // dot|single|two|three|four|six|wicket|wide|no_ball
    "batter": "Suryakumar Yadav",
    "batter_runs": 45,
    "batter_balls": 28,
    "bowler": "Boult",
    "bowler_figures": "3-0-24-1",
    "delivery": {            // from OCR (speed) + pitch map graphic (line/length)
        "speed_kph": 137.4,  // null if not captured
        "line": "outside_off", // null if no pitch map shown
        "length": "good",
        "type": "seam"       // seam|spin|medium — inferred from speed+bowler
    },
    "shot": {                // from optical flow + replay analysis
        "type": "cut",       // null if no replay; inferred from direction if possible
        "direction": "point", // from wagon wheel graphic or optical flow
        "elevation": "along_ground",
        "foot": "back_foot", // from replay analysis only
        "power": "timed"     // inferred from delivery speed + result
    },
    "field": {               // from YOLO on live_delivery frames
        "off_side": 5,
        "leg_side": 4,
        "slips": 1,
        "description": "1 slip, gully, point up, deep cover"
    },
    "atmosphere": {          // from player closeup + crowd analysis
        "batter_emotion": "confident",  // null if no closeup captured
        "bowler_emotion": "frustrated",
        "crowd_energy": "roaring"
    },
    "timestamp": 1709913600.0
}}

// Full match state (sent on every ball + on client connect)
{"type": "state_update", "data": {
    "innings": 2,
    "batting_team": "New Zealand",
    "bowling_team": "India",
    "score": 142,
    "wickets": 3,
    "overs": "16.3",
    "target": 176,
    "run_rate": 8.67,
    "required_rate": 9.71,
    "projected_score": 173,
    "phase": "death",           // powerplay|middle|death
    "momentum_index": 0.45,     // -1.0 to 1.0
    "win_probability": 0.58,    // 0.0 to 1.0
    "dot_ball_pct": 0.33,
    "boundary_pct": 0.22,
    "batter_on_strike": {"name": "Allen", "runs": 78, "balls": 41, "fours": 6, "sixes": 5},
    "batter_non_strike": {"name": "Ravindra", "runs": 22, "balls": 18},
    "bowler": {"name": "Bumrah", "overs": "3.3", "runs": 28, "wickets": 1, "economy": 8.0},
    "partnership": {"runs": 48, "balls": 32},
    "bowling_figures": [
        {"name": "Bumrah", "overs": "3.3", "runs": 28, "wickets": 1, "remaining": 0.3},
        {"name": "Hardik", "overs": "3", "runs": 31, "wickets": 0, "remaining": 1}
    ],
    "over_by_over": [{"over": 1, "runs": 8, "wickets": 0}, ...],
    "fall_of_wickets": [{"wicket": 1, "score": 24, "overs": "3.4", "batter": "Seifert"}],
    "this_over": ["dot", "four", "single"]
}}

// Commentary tiers (arrive sequentially after ball_event)
{"type": "commentary_t1", "data": {
    "text": "Full and driven through covers. Four runs.",
    "tier": 1,
    "voice_situation": "four_boundary",
    "should_voice": true,
    "voice_profile": "main",
    "timestamp": 1709913601.0
}}

{"type": "commentary_t2", "data": {
    "text": "Third boundary through the off side this over...",
    "tier": 2,
    "timestamp": 1709913603.0
}}

{"type": "commentary_t3", "data": {
    "text": "Something shifted in Allen's demeanor [pause] ...",
    "tier": 3,
    "voice_situation": "narrative_dramatic",
    "voice_profile": "narrator",
    "timestamp": 1709913605.0
}}

// Audio clip ready to play
{"type": "audio", "data": {
    "url": "/static/audio/abc123def456.wav",
    "duration": 3.2,
    "silence_before": 0.5,  // seconds to wait before playing
    "voice": "main",        // main|narrator
    "situation": "four_boundary"
}}

// Active narrative storylines
{"type": "narrative_update", "data": [
    {"id": "n1", "title": "Allen's century chase", "type": "milestone_chase",
     "status": "developing", "description": "22 runs away from fastest WC final century"},
    {"id": "n2", "title": "Bumrah's death spell", "type": "bowling_spell",
     "status": "climax", "description": "Economy of 8.0, one wicket, final over coming"}
]}

// Prediction/challenge prompt
{"type": "engagement", "data": {
    "id": "pred_001",
    "question": "How many runs in the next over?",
    "options": ["0-4", "5-8", "9-12", "13+"],
    "type": "prediction",           // prediction|challenge
    "closes_in_seconds": 30
}}

// Prediction resolved
{"type": "prediction_result", "data": {
    "id": "pred_001",
    "correct_answer": "9-12",
    "scores": {"anmol": 10, "team_member": 5}
}}

// Chat from another user
{"type": "chat_message", "data": {
    "user": "anmol",
    "text": "Why isn't he bowling Bumrah?",
    "timestamp": 1709913610.0
}}

// AI response in chat
{"type": "chat_ai_response", "data": {
    "in_reply_to": "Why isn't he bowling Bumrah?",
    "text": "Bumrah has 0.3 overs left — Rohit is saving him for...",
    "timestamp": 1709913612.0
}}

// User comment featured in main commentary feed
{"type": "featured_comment", "data": {
    "user": "anmol",
    "text": "Notice Williamson standing wider at first slip",
    "ai_annotation": "Sharp observation — Santner's drift takes edges wider against lefties"
}}

// Aggregated emotional reactions
{"type": "crowd_pulse", "data": {
    "distribution": {"🔥": 0.45, "😰": 0.30, "🎉": 0.10, "😤": 0.08, "😱": 0.05, "💀": 0.02},
    "dominant": "🔥",
    "total_reactions": 8
}}

// Retroactive enrichment from replay analysis (arrives after initial commentary)
{"type": "commentary_enrichment", "data": {
    "ball_number": "16.3",
    "detail": {
        "shot_type": "cut",
        "foot": "back_foot",
        "ball_movement": "seam_away",
        "contact": "middle"
    },
    "text": "The replay confirms it — Boult got good seam movement away from the right-hander, but SKY was right on top of it, rocking back and cutting with full control."
}}

// Vision system detected notable broadcast content
{"type": "vision_observation", "data": {
    "scene_type": "player_closeup",
    "observation": {"player": "bowler", "emotion": "frustrated", "action": "head_shake"},
    "timestamp": 1709913608.0
}}
```

### Client → Server Messages

```jsonc
{"type": "set_username", "data": {"username": "anmol"}}

{"type": "chat_message", "data": {"user": "anmol", "text": "Great shot!"}}

// Response to an engagement prompt
{"type": "prediction", "data": {"user": "anmol", "prediction_id": "pred_001", "value": "9-12"}}

// Per-ball quick predict
{"type": "quick_predict", "data": {"user": "anmol", "prediction": "four"}}
// prediction values: dot|single|two|three|four|six|wicket

// Emotional reaction
{"type": "reaction", "data": {"user": "anmol", "emoji": "🔥"}}
```

### REST Endpoints

```
POST /setup/match    → {team_a, team_b, format, event?, venue?, date?, is_live} starts context build
POST /setup/quick    → {teams: "India vs New Zealand"} fast start, assumes T20I
POST /setup/reset    → clears match state, returns to setup screen (models stay loaded)
GET  /setup/status   → {state, match, context_status, calibration, observation stats}
POST /setup/calibrate → {scoreboard_region: [x1,y1,x2,y2]} set scoreboard crop area
POST /setup/go-live  → transitions from CALIBRATING to LIVE, starts observation loop
GET  /state          → current state_update payload
GET  /commentary     → array of all commentary items this match
GET  /predictions/leaderboard → [{user, score, correct, total}]
GET  /health         → {status, models_loaded, connected_clients}
```

### On Client Connect

Server immediately sends:
1. `state_update` with current full state
2. Last 20 `commentary_t1/t2/t3` messages (for scroll-back)
3. `narrative_update` with active threads
4. Current `engagement` prompt if one is open
5. `crowd_pulse` current state
