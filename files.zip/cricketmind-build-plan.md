# CricketMind — Build Plan (Final)

## Reference Docs

- docs/architecture.md — system design, data flow, loops, memory budget
- docs/vision-pipeline.md — continuous observation, scene types, extractors
- docs/match-setup.md — match selection, context loading, calibration flow
- docs/api-contract.md — WebSocket messages, REST endpoints
- docs/frontend-spec.md — component specs, theme, layout
- docs/cricket-domain.md — T20/ODI/Test rules, phases, metrics
- docs/context-builder.md — pre-match historical data scraper

## Install

```bash
brew install ollama cloudflared
ollama pull moondream && ollama pull mistral:7b
python3.11 -m venv .venv && source .venv/bin/activate
pip install fastapi uvicorn websockets mss pillow httpx beautifulsoup4 \
    chatterbox-tts torch torchaudio paddlepaddle paddleocr \
    ultralytics opencv-python-headless
npx create-vite@latest frontend --template react
cd frontend && npm install recharts lucide-react
```

Note: no more llava:13b — replaced by PaddleOCR (scoreboard) +
YOLO v8 nano (field) + Moondream 1.7B (graphics/emotion/replay).
Saves ~6GB RAM, faster, more accurate.

## Voice Samples

Pick 2 → `voices/main_commentator.wav` (energetic) +
`voices/narrator.wav` (calm). WAV, 24kHz+, 10s+, clean.

---

# DAY 1: THE ENGINE

## Session 1: Types + Config + Prompts (~30 min)

```
Create shared foundation per docs/architecture.md.

backend/types.py — dataclasses: BallEvent (now includes delivery,
shot, field, atmosphere sub-objects — see enriched event in
docs/vision-pipeline.md), StateUpdate, CommentaryOutput, AudioOutput

backend/config.py — EMOTION_MAP, SILENCE_MAP, VOICE_PROFILES,
OLLAMA_URL, COMMENTARY_MODEL, CAPTURE_FPS, plus scene classifier
thresholds

backend/prompts/ — tier1.txt, tier2.txt, tier3.txt, plus new prompts:
graphics_reader.txt, emotion_reader.txt, replay_analyzer.txt
(all prompts defined in docs/vision-pipeline.md extractor sections)
```

## Session 2: Vision Pipeline — Capture + Scene + OCR + Field (~3 hours)

```
Build the continuous observation system.
Full spec in docs/vision-pipeline.md.
Types in backend/types.py.

backend/capture.py — mss at 2fps, region selector (tkinter),
frames into asyncio.Queue

backend/scene_classifier.py — classifies frames into scene types:
live_delivery, graphic_overlay, player_closeup, replay_slow_motion,
crowd_shot, field_setting_view, ad_break, analysis_segment.
Use rule-based approach: green ratio, face detection, frame diff,
scoreboard presence check. See docs/vision-pipeline.md for logic.

backend/scoreboard_ocr.py — PaddleOCR on scoreboard crop region.
Extract score, overs, batters, bowler, speed. Crop region set
during calibration (user clicks corners). detect_new_ball() compares
current vs previous OCR to find new deliveries.

backend/field_detector.py — YOLO v8 nano detecting persons on
wide-angle frames (live_delivery scenes). Map bounding box positions
to cricket field zones using pitch location as reference center.
Output: {off_side: N, leg_side: N, slips: N, description: str}

backend/shot_analyzer.py — Two components:
1. OpenCV optical flow on live frames → ball direction (off/leg,
   ground/aerial) — runs in <100ms
2. Shot frame buffer: collect 3-5 frames during delivery, classify
   shot intent (attack/defense/leave) from motion patterns
```

## Session 3: Vision Pipeline — Moondream + Enrichment (~2 hours)

```
Add Moondream-powered extractors for richer data.
Prompts defined in docs/vision-pipeline.md.

backend/vision.py — The observation loop orchestrator.
Routes frames from capture to scene_classifier, then to appropriate
extractor. Manages shot_frame_buffer, replay_queue, prev_ocr state.
Triggers process_ball_event() when new ball detected.
Full loop code in docs/architecture.md and docs/vision-pipeline.md.

Moondream extractors (all async, non-blocking):
- Graphics reader: when graphic_overlay has non-scoreboard content,
  send to Moondream to extract pitch_map/wagon_wheel/stats data
- Emotion reader: on player_closeup, classify emotion + action
- Replay analyzer: on replay_slow_motion frames, extract shot_type,
  foot_movement, ball_movement, contact quality
- Crowd reader: on crowd_shot, classify energy level

All Moondream calls use same ollama_generate() pattern with
image_b64 parameter. Prompts loaded from prompts/ directory.

Enrichment flow: Moondream results update game_state or retroactively
enrich the last BallEvent. Commentary engine accesses latest data
on each generation.
```

## Session 4: Game State + Commentary + Narrative (~2 hours)

```
Build state engine and commentary generation.
Types in backend/types.py. Cricket rules in docs/cricket-domain.md.
Prompts in backend/prompts/tier1.txt, tier2.txt, tier3.txt.

backend/game_state.py — GameState class. Now also stores:
- last_field (from field_detector), last_shot_direction (optical flow)
- emotion_observations (accumulated from closeup analysis)
- atmosphere (from crowd analysis)
- Methods: update(), update_field(), update_atmosphere(),
  update_shot_direction(), enrich_last_ball(), get_commentary_context(),
  to_client_payload()

backend/commentary.py — 3 tiers. Tier 1 now gets delivery + shot
data for richer descriptions. Tier 2 gets field setting data for
tactical analysis. Tier 3 gets emotion observations for narrative.
Voice assignment and trigger logic unchanged.

backend/narrative.py — Now also creates threads from:
- emotion_shift: detected emotion change over multiple closeups
- field_change: captain changed field tactically
- atmosphere_shift: crowd energy changed significantly
```

## Session 5: Audio + Server + Match Setup + Integration (~2.5 hours)

```
Wire everything together.
Architecture in docs/architecture.md.
WebSocket contract in docs/api-contract.md.
Match setup flow in docs/match-setup.md.
Context builder spec in docs/context-builder.md.

backend/audio.py — Chatterbox Turbo, 2 voices, emotion map,
silence map. Unchanged from previous plan.

backend/main.py — FastAPI server. State machine:
IDLE → SETUP → BUILDING_CONTEXT → CALIBRATING → LIVE → MATCH_COMPLETE
See docs/match-setup.md for full state machine and endpoints.

Setup endpoints: POST /setup/match, /setup/quick, /setup/reset,
/setup/calibrate, /setup/go-live, GET /setup/status.
On "go-live": starts observation_loop, replay_analyzer_loop,
chat_response_loop, audio_cleanup_loop.
On "reset": clears all match state, keeps models loaded,
returns to IDLE. Enables testing multiple matches without restart.

backend/engagement.py — predictions, quick-predict, leaderboard
backend/chat_handler.py — buffer, AI response, featured comments
backend/context_builder.py — pre-match scraper per docs/context-builder.md.
  Adapts to format (T20I/ODI/Test) and is_live flag.
  For historical matches: finds the specific scorecard but doesn't
  spoil results to commentary engine.
```

## Session 6: End-to-End YouTube Test (~1 hour)

```
Manual testing — no Cursor prompt.

1. YouTube T20 replay (HD, visible scoreboard)
2. Start: ollama serve → uvicorn → capture selector
3. Watch 2-3 overs, verify:
   □ Scene classifier correctly identifying frame types
   □ OCR reading scoreboard accurately
   □ Ball events detected on score changes
   □ YOLO detecting fielder positions on live frames
   □ Moondream extracting graphics/emotion/replay data
   □ Commentary referencing field settings and shot details
   □ Audio working with correct voices and emotion
4. Key things to tune:
   - Scene classifier thresholds (green ratio, etc.)
   - Scoreboard crop region precision
   - YOLO confidence threshold for person detection
   - Commentary prompts using enriched data naturally
```

---

# DAY 2: THE FRONTEND

## Session 7: Full React App (~4 hours)

```
Build complete React frontend.
Component specs in docs/frontend-spec.md.
WebSocket messages in docs/api-contract.md.
Match setup flow in docs/match-setup.md.
Cricket context in docs/cricket-domain.md.

App.jsx routes by server state:
  IDLE/SETUP → SetupScreen (match entry form)
  BUILDING_CONTEXT → ContextLoadingScreen (progress indicators)
  CALIBRATING → CalibrationScreen (scoreboard region instructions)
  LIVE/MATCH_COMPLETE → MatchView (full commentary experience)
See docs/match-setup.md for component specs and routing logic.

All match view components, hooks, and layout as specified in
docs/frontend-spec.md. Single session — all components built
with shared context.
```

## Session 8: Deploy + Polish + Full Test (~2 hours)

```
Production build + deploy per docs/architecture.md.
Polish: loading states, connection indicator, error resilience,
mobile layout. Visual specs in docs/frontend-spec.md.

cloudflared tunnel --url http://localhost:8000

Full test on YouTube replay:
□ All scene types detected and data extracted
□ Commentary references field settings, shot details, emotions
□ Audio emotion varies with match situation
□ Stats/animation/engagement all working
□ Mobile layout usable
□ Multi-user WebSocket works
```

---

# MATCH DAY

```
1hr before: start ollama, uvicorn, cloudflared → share URL
Open localhost:8000 → enter match: India vs New Zealand, T20I,
  "T20 World Cup 2026 Final", Narendra Modi Stadium, 2026-03-08, Live
Wait ~90s for context to build
Open broadcast stream, calibrate scoreboard region
Click "Go Live" when broadcast starts pre-match coverage
```

# Testing Workflow

```
1. Start server (models load once)
2. Open localhost:8000 → setup screen
3. Enter any match: "India vs Australia, T20I, 2024 World Cup"
4. Wait for context (~60s)
5. Open YouTube replay, calibrate, go live
6. Test for a few overs
7. POST /setup/reset → back to setup screen
8. Enter different match → repeat
No restart needed between matches.
```

# Emergency Cuts (in order)

1. MatchAnimation → just text + audio
2. EmotionalPulse → keep predictions + chat
3. Moondream extractors (emotion/replay/graphics) → OCR + YOLO only
4. StoryStrip → feed is enough
5. Tier 3 commentary → just Tier 1 + 2
6. Chat AI responses → user chat only
7. Narrator voice → main voice only
8. YOLO field detection → scoreboard OCR only

**Minimum demo:** OCR scoreboard → State → Tier 1 commentary →
Main voice audio → Score + Commentary + Win Probability

# Model Reference

| Task | Model | RAM | Speed |
|------|-------|-----|-------|
| Scene classification | Rule-based + OpenCV | ~50 MB | <50ms |
| Scoreboard OCR | PaddleOCR | ~500 MB | <500ms |
| Field detection | YOLO v8 nano | ~200 MB | ~50ms |
| Shot direction | OpenCV optical flow | ~50 MB | <100ms |
| Graphics/emotion/replay | Moondream 1.7B (Ollama) | ~2 GB | ~2-3s |
| Commentary text | Mistral 7B (Ollama) | ~5 GB | ~1-2s |
| Audio synthesis | Chatterbox Turbo | ~3 GB | ~1-3s |
| **Total: ~17.8 GB** | **Headroom: ~14.2 GB** | | |
